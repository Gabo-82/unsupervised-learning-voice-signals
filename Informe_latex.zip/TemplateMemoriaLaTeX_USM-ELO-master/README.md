Template Memoria LaTeX USM-ELO
==============================

Template hecho en LaTeX para el departamento de electrónica, UTFSM. Estilo obligatorio del departamento.

Agradecimientos para Natalia Vásquez y Nicolás Alvarez, titulados de Ing. Civil Telemática UTFSM.